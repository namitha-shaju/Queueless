(() => {
 let mode = 'login';
 const $ = id => document.getElementById(id);
 const switchMode = next => {
   mode = next;
   $('loginTab').classList.toggle('active', mode === 'login');
   $('signupTab').classList.toggle('active', mode === 'signup');
   $('nameField').classList.toggle('hidden', mode !== 'signup');
   $('patientName').required = mode === 'signup';
   $('accountSubmit').textContent = mode === 'signup' ? 'Sign Up' : 'Login';
   $('accountFeedback').textContent = '';
 };
 $('loginTab').addEventListener('click', () => switchMode('login'));
 $('signupTab').addEventListener('click', () => switchMode('signup'));
 const modal = $('login');
 const openLogin = (signup=false) => {switchMode(signup?'signup':'login');modal.classList.add('modal-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('modal-visible');setTimeout(()=>$('accountEmail').focus(),100);};
 const closeLogin = () => {modal.classList.remove('modal-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('modal-visible');};
 document.querySelectorAll('a[href="#login"],a[href="#signup"]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();openLogin(a.id==='footerSignup'||a.getAttribute('href')==='#signup');}));
 $('closeLogin').addEventListener('click',closeLogin);
 modal.addEventListener('click',e=>{if(e.target===modal)closeLogin();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeLogin();});
 $('accountForm').addEventListener('submit', event => {
   event.preventDefault();
   const name = $('patientName').value.trim();
   if (mode === 'signup' && !name) return;
   const email = $('accountEmail').value.trim();
   const displayName = name || email.split('@')[0];
   if ($('accountRole').value === 'patient') {
     const profileKey='ql_profile_'+email.toLowerCase();
     const existing=JSON.parse(localStorage.getItem(profileKey)||'{}');
     const profile={...existing,name:mode==='signup'?displayName:(existing.name||displayName),email};
     localStorage.setItem(profileKey,JSON.stringify(profile));
     sessionStorage.setItem('ql_current_profile',profileKey);
     localStorage.setItem('ql_last_profile',profileKey);
     window.qlRenderProfile?.();
   }
   if (['staff','admin'].includes($('accountRole').value)) { closeLogin(); document.body.classList.add('staff-active'); document.body.classList.remove('dashboard-active'); window.qlStaffRender?.(); window.qlSetStaffRole?.($('accountRole').value); location.hash='staff'; window.scrollTo(0,0); return; }
   $('dashboardGreeting').textContent = 'Welcome, ' + (JSON.parse(localStorage.getItem(sessionStorage.getItem('ql_current_profile')||localStorage.getItem('ql_last_profile'))||'{}').name||displayName) + '!';
   $('tokenPatient').value = JSON.parse(localStorage.getItem(sessionStorage.getItem('ql_current_profile')||localStorage.getItem('ql_last_profile'))||'{}').name||displayName;
   closeLogin();
   window.qlRenderProfile?.();
   document.body.classList.add('dashboard-active');
   $('patientDashboard').classList.remove('sidebar-collapsed');
   syncSidebar();
   location.hash = 'dashboard';
   window.scrollTo(0,0);
   const saved = sessionStorage.getItem('queuelessToken');
   if(saved) { try { const t=JSON.parse(saved); $('tokenNumber').textContent=t.number; $('receiptName').textContent=t.name; $('receiptTime').textContent=t.time; $('receiptDate').textContent=t.date; $('receiptDepartment').textContent=t.department; $('tokenResult').classList.remove('hidden'); $('dashboardStatus').textContent='Token '+t.number+' for '+t.department; setJoinState(!!t.joined,t.number); } catch(e) {} }
 });
 const setJoinState = (joined, number) => {
   const hasToken = !!number;
   $('joinQueueButton').disabled = !hasToken || joined;
   $('joinQueueButton').textContent = joined ? '✓ Joined Queue' : hasToken ? 'Join Queue Now →' : 'Book a Token First';
   $('joinQueueStatus').textContent = joined ? 'You are in the waiting line' : hasToken ? 'Token ready — join when you are ready' : 'Not joined yet';
   if(joined) updateQueue(number);
   else {
     $('nowServing').textContent = '—';$('queuePosition').textContent = hasToken ? number : '—';
     $('peopleAhead').textContent = '—';$('waitTime').textContent = '—';
     $('queueProgress').style.width='0%';$('queueLine').replaceChildren();
     $('queueMessage').textContent=hasToken?'Your token is booked. Select Join Queue to enter the waiting line.':'Book a token to see your queue details.';
   }
 };
 $('joinQueueButton').addEventListener('click',()=>{
   let t;try{t=JSON.parse(sessionStorage.getItem('queuelessToken')||'null')}catch(e){}
   if(!t || t.joined)return;
   t.joined=true;sessionStorage.setItem('queuelessToken',JSON.stringify(t));window.qlStoreBookedToken?.(t);window.qlAddToQueue?.(t);setJoinState(true,t.number);
   $('queue').scrollIntoView({behavior:'smooth',block:'start'});
 });
 const updateQueue = number => {
   const live = window.qlQueueSnapshot?.();
   if(live){const ahead=live.waiting.findIndex(x=>x.number===number); const active=live.serving?.number===number; const count=active?0:Math.max(0,ahead);$('nowServing').textContent=live.serving?.number||'—';$('queuePosition').textContent=number;$('peopleAhead').textContent=ahead<0&&!active?'—':count;$('waitTime').textContent=ahead<0&&!active?'—':(count*5)+' min';$('queueProgress').style.width=active?'100%':(ahead<0?'0%':Math.max(8,100/(count+2)))+'%';$('queueMessage').textContent=active?'Your token is now being served.':ahead<0?'Your token is not currently in the waiting queue.':count+' patient(s) ahead of you.';$('queueLine').replaceChildren();live.waiting.slice(0,12).forEach(x=>{const c=document.createElement('div');c.className='queue-person'+(x.number===number?' mine':'');const strong=document.createElement('strong');strong.textContent=x.number;const span=document.createElement('span');span.textContent=x.number===number?'You':'Waiting';c.append(strong,span);$('queueLine').append(c)});return;}
   $('nowServing').textContent = 'QL-018';
   $('queuePosition').textContent = number;
   $('peopleAhead').textContent = '5';
   $('waitTime').textContent = '25 min';
   $('queueProgress').style.width = '17%';
   $('queueMessage').textContent = '5 patients are ahead of you. Estimated waiting time: 25 minutes.';
   $('queueLine').innerHTML = '';
   for(let i=0;i<6;i++) {
     const cell=document.createElement('div');cell.className='queue-person'+(i===5?' mine':'');
     const label=document.createElement('strong');label.textContent=i===5?number:'QL-'+String(19+i).padStart(3,'0');
     const status=document.createElement('span');status.textContent=i===5?'You':'Waiting';
     cell.append(label,status);$('queueLine').appendChild(cell);
   }
 };
 const today = new Date();
 const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0,10);
 $('tokenDate').min = localDate;
 $('tokenForm').addEventListener('submit', event => {
   event.preventDefault();
   const name = $('tokenPatient').value.trim();
   if (!name || $('tokenDate').value < localDate) return;
   let number;
   try { number = window.qlGenerateUniqueToken($('tokenDepartment').value, $('tokenDate').value); } catch(error) { alert(error.message); return; }
   $('tokenNumber').textContent = number;
   $('receiptName').textContent = name;
   $('receiptTime').textContent = $('tokenTime').value;
   $('receiptDate').textContent = $('tokenDate').value;
   $('receiptDepartment').textContent = $('tokenDepartment').value;
   $('tokenResult').classList.remove('hidden');
   $('dashboardStatus').textContent = 'Token ' + number + ' for ' + $('tokenDepartment').value;
   setJoinState(false,number);
   const booked={number,name,time:$('tokenTime').value,date:$('tokenDate').value,department:$('tokenDepartment').value};
   sessionStorage.setItem('queuelessToken', JSON.stringify(booked));
   window.qlStoreBookedToken?.(booked);
   $('tokenResult').scrollIntoView({behavior:'smooth',block:'center'});
 });
 $('dashboardBookNow').addEventListener('click', () => $('tokens').scrollIntoView({behavior:'smooth'}));
 $('tileJoinQueue').addEventListener('click', () => $('joinQueue').scrollIntoView({behavior:'smooth'}));
 $('tileBook').addEventListener('click', () => $('tokens').scrollIntoView({behavior:'smooth'}));
 $('tileDepartments').addEventListener('click', () => { $('tokens').scrollIntoView({behavior:'smooth'}); $('tokenDepartment').focus({preventScroll:true}); });
 $('tileMyToken').addEventListener('click', () => ($('tokenResult').classList.contains('hidden') ? $('tokens') : $('tokenResult')).scrollIntoView({behavior:'smooth'}));
 const syncSidebar=()=>{const collapsed=$('patientDashboard').classList.contains('sidebar-collapsed');$('sidebarToggle').setAttribute('aria-expanded',String(!collapsed));$('sidebarToggle').setAttribute('aria-label',collapsed?'Open navigation':'Close navigation');$('sidebarToggle').textContent=collapsed?'☰':'✕';};
 $('sidebarToggle').addEventListener('click',()=>{$('patientDashboard').classList.toggle('sidebar-collapsed');syncSidebar();});
 $('sidebarBackdrop').addEventListener('click',()=>{$('patientDashboard').classList.add('sidebar-collapsed');syncSidebar();});
 document.querySelectorAll('[data-dash-target]').forEach(link => link.addEventListener('click', e => { e.preventDefault(); document.querySelectorAll('[data-dash-target]').forEach(x=>x.classList.remove('active'));link.classList.add('active');$(link.dataset.dashTarget).scrollIntoView({behavior:'smooth'});if(matchMedia('(max-width:950px)').matches){$('patientDashboard').classList.add('sidebar-collapsed');syncSidebar();} }));
 $('printToken').addEventListener('click', () => window.print());
 $('logoutButton').addEventListener('click', () => {
   $('patientDashboard').classList.add('sidebar-collapsed');syncSidebar();
   document.body.classList.remove('dashboard-active');
   $('accountForm').reset();
   $('tokenForm').reset();
   $('tokenResult').classList.add('hidden');
   $('dashboardStatus').textContent = 'No token booked yet.';
   setJoinState(false,null);
   $('nowServing').textContent = $('queuePosition').textContent = $('peopleAhead').textContent = '—';
   $('queueProgress').style.width='0%';
   $('waitTime').textContent='—';
   $('queueLine').innerHTML='';
   $('queueMessage').textContent='Book a token to see your queue details.';
   sessionStorage.removeItem('queuelessToken');
   sessionStorage.removeItem('ql_current_profile');
   location.hash = 'home';
   window.scrollTo(0,0);
 });
})();
