(()=>{
const $=id=>document.getElementById(id);
const dateInput=$('reportDate');
const localDate=d=>{const dt=new Date(d);return Number.isFinite(dt.getTime())?dt.getFullYear()+'-'+String(dt.getMonth()+1).padStart(2,'0')+'-'+String(dt.getDate()).padStart(2,'0'):''};
dateInput.value=localDate(Date.now());
const timeOf=v=>{if(typeof v==='number'&&v>1000000000000)return v;if(typeof v==='string'&&v){const n=Date.parse(v);return Number.isFinite(n)?n:null}return null};
const clock=t=>t?new Date(t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'—';
const minutes=ms=>ms===null?'—':Math.round(ms/60000)+' min';
const safe=(v)=>String(v??'');
const csvEscape=v=>'"'+safe(v).replace(/"/g,'""')+'"';
function data(){
 const q=window.qlQueueSnapshot?.()||{waiting:[],history:[],skipped:[]};
 const rows=[...(q.waiting||[]).map(t=>({...t,status:'Waiting'})),...(q.serving?[{...q.serving,status:'Serving'}]:[]),...(q.history||[]).map(t=>({...t,status:'Completed'})),...(q.skipped||[]).map(t=>({...t,status:'Skipped'}))];
 return rows.map(t=>{
 const arrived=timeOf(t.joinedAt)||timeOf(t.createdAt)||timeOf(t.date);
 const called=timeOf(t.calledAt),completed=timeOf(t.completedAtMs)||timeOf(t.completedAt);
 const skipped=timeOf(t.skippedAtMs);
 const day=localDate(arrived||called||completed||skipped);
 return {...t,arrived,called,completed,skipped,day,waitMs:arrived&&called&&called>=arrived?called-arrived:null,serviceMs:called&&completed&&completed>=called?completed-called:null};
 }).filter(t=>t.day===dateInput.value&&!t.example);
}
function build(){
 const rows=data();
 $('reportVolume').textContent=rows.length;
 const average=key=>{const values=rows.map(t=>t[key]).filter(v=>v!==null);return values.length?minutes(values.reduce((a,b)=>a+b,0)/values.length):'—'};
 $('reportWait').textContent=average('waitMs');
 $('reportService').textContent=average('serviceMs');
 $('reportCompleted').textContent=rows.filter(t=>t.status==='Completed').length;
 $('reportSkipped').textContent=rows.filter(t=>t.status==='Skipped').length;
 const hours=Array(24).fill(0);rows.forEach(t=>{if(t.arrived)hours[new Date(t.arrived).getHours()]++});
 const peak=Math.max(...hours);$('reportPeak').textContent=peak?clock(new Date(dateInput.value+'T'+String(hours.indexOf(peak)).padStart(2,'0')+':00:00').getTime()):'—';
 const bars=$('reportHourly');bars.replaceChildren();
 for(let h=0;h<24;h++){const wrap=document.createElement('div');wrap.className='report-bar-column';wrap.title=h+':00 — '+hours[h]+' arrivals';const bar=document.createElement('div');bar.className='report-bar';bar.style.height=(peak?Math.max(3,hours[h]/peak*100):3)+'%';const label=document.createElement('small');label.textContent=h%3===0?String(h).padStart(2,'0'):'';wrap.append(bar,label);bars.append(wrap)}
 const outcomes=$('reportOutcomes');outcomes.replaceChildren();
 for(const status of ['Waiting','Serving','Completed','Skipped']){const count=rows.filter(t=>t.status===status).length;const item=document.createElement('div');item.className='report-outcome-row';const label=document.createElement('span');label.textContent=status;const track=document.createElement('div');track.className='report-track';const fill=document.createElement('div');fill.className='report-fill';fill.style.width=(rows.length?count/rows.length*100:0)+'%';track.append(fill);const value=document.createElement('strong');value.textContent=count;item.append(label,track,value);outcomes.append(item)}
 const tbody=$('reportRows');tbody.replaceChildren();
 rows.forEach(t=>{const tr=document.createElement('tr');[t.number||'—',t.department||'—',clock(t.arrived),minutes(t.waitMs),minutes(t.serviceMs),t.status].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td)});tbody.append(tr)});
 $('reportEmpty').hidden=rows.length!==0;
}
window.qlRenderReports=build;
dateInput.addEventListener('change',build);
$('reportExport').addEventListener('click',()=>{
 const rows=data();
 const head=['Token','Patient','Department','Arrival','Waiting minutes','Service minutes','Status'];
 const body=rows.map(t=>[t.number,t.name,t.department,t.arrived?new Date(t.arrived).toLocaleString():'',t.waitMs===null?'':(t.waitMs/60000).toFixed(1),t.serviceMs===null?'':(t.serviceMs/60000).toFixed(1),t.status]);
 const csv=[head,...body].map(row=>row.map(csvEscape).join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='queueless-report-'+dateInput.value+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
build();
})();
