(()=>{
const $=id=>document.getElementById(id);
const tokenKey=()=>{const k=sessionStorage.getItem('ql_current_profile')||localStorage.getItem('ql_last_profile');return k?'ql_tokens_'+k:null};
const loadTokens=()=>{try{return JSON.parse(localStorage.getItem(tokenKey())||'[]')}catch(e){return []}};
window.qlStoreBookedToken=t=>{const k=tokenKey();if(!k)return;const tokens=loadTokens().filter(x=>x.number!==t.number);tokens.unshift(t);try{localStorage.setItem(k,JSON.stringify(tokens.slice(0,50)))}catch(e){};};
window.qlRenderTokens=()=>{const root=$('profileTokenList');if(!root)return;root.replaceChildren();const tokens=loadTokens();const current=(()=>{try{return JSON.parse(sessionStorage.getItem('queuelessToken')||'null')}catch(e){return null}})();if(current&&!tokens.some(t=>t.number===current.number)){tokens.unshift(current)};$('profileTokenCount').textContent=tokens.length+' token'+(tokens.length===1?'':'s');if(!tokens.length){const empty=document.createElement('p');empty.textContent='No tokens booked yet. Book a token from your dashboard to see it here.';root.append(empty);return;}const q=window.qlQueueSnapshot?.();tokens.forEach(t=>{const card=document.createElement('article');card.className='profile-token-card';const title=document.createElement('div');title.className='profile-token-title';const num=document.createElement('strong');num.textContent=t.number||'Token';const status=document.createElement('span');status.className='profile-token-status';let label='Booked';if(q){if(q.serving?.number===t.number)label='Now Serving';else if((q.waiting||[]).some(x=>x.number===t.number))label='Waiting';else if((q.history||[]).some(x=>x.number===t.number))label='Completed';else if(t.joined)label='Joined Queue';}status.textContent=label;title.append(num,status);const details=document.createElement('p');details.textContent=[t.department,t.date,t.time].filter(Boolean).join('  •  ');const patient=document.createElement('small');patient.textContent=t.name||'';card.append(title,details,patient);root.append(card)})};
window.qlRenderProfile=()=>{
 const key=sessionStorage.getItem('ql_current_profile')||localStorage.getItem('ql_last_profile');
 if(!key)return;
 let p={};try{p=JSON.parse(localStorage.getItem(key)||'{}')}catch(e){}
 $('profileName').value=p.name||'';$('profileEmail').value=p.email||'';
 $('profilePhone').value=p.phone||'';$('profileAge').value=p.age||'';
 $('profileAddress').value=p.address||'';
 $('profileAvatar').textContent=(p.name||'P').charAt(0).toUpperCase();
 $('profileNotice').textContent='';
 window.qlRenderTokens?.();
 $('profileTopAvatar').textContent=(p.name||'P').charAt(0).toUpperCase();
 $('profileTopName').textContent=p.name||'My Account';
 $('profileDropdownName').textContent=p.name||'Patient';
 $('profileDropdownEmail').textContent=p.email||'';
};
$('tileProfile')?.addEventListener('click',()=>{
 window.qlRenderProfile?.();
 window.qlOpenProfilePage?.();
});
$('profileForm').addEventListener('submit',e=>{
 e.preventDefault();const key=sessionStorage.getItem('ql_current_profile')||localStorage.getItem('ql_last_profile');if(!key)return;
 const p={name:$('profileName').value.trim(),email:$('profileEmail').value,phone:$('profilePhone').value.trim(),age:$('profileAge').value,address:$('profileAddress').value.trim()};
 if(!p.name)return;
 try { localStorage.setItem(key,JSON.stringify(p)); }
 catch(error){$('profileNotice').textContent='Unable to save in this browser. Check storage permissions.';return;}
 $('profileAvatar').textContent=p.name[0].toUpperCase();
 $('profileTopAvatar').textContent=p.name[0].toUpperCase();
 $('profileTopName').textContent=p.name;
 $('profileDropdownName').textContent=p.name;
 $('dashboardGreeting').textContent='Welcome, '+p.name+'!';
 $('tokenPatient').value=p.name;
 $('profileNotice').textContent='Profile updated successfully.';
});
window.qlOpenProfilePage=()=>{window.qlRenderProfile?.();document.body.classList.add('profile-page-active');$('profilePage').hidden=false;window.scrollTo(0,0)};
const closeProfilePage=()=>{document.body.classList.remove('profile-page-active');$('profilePage').hidden=true;window.scrollTo(0,0)};
$('profileBack').addEventListener('click',closeProfilePage);
$('logoutButton').addEventListener('click',closeProfilePage);
document.querySelectorAll('[data-dash-target="profile"]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();window.qlOpenProfilePage?.()}));
const menu=$('profileDropdown'),trigger=$('profileMenuButton');
const closeMenu=()=>{menu.hidden=true;trigger.setAttribute('aria-expanded','false')};
trigger.addEventListener('click',()=>{closeMenu();window.qlOpenProfilePage?.()});
$('openProfileFromMenu').addEventListener('click',()=>{closeMenu();window.qlRenderProfile?.();window.qlOpenProfilePage?.()});
$('profileMenuLogout').addEventListener('click',()=>{closeMenu();$('logoutButton').click()});
document.addEventListener('click',e=>{if(!e.target.closest('.profile-menu-wrap'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
function adminRender(){
 if(!document.body.classList.contains('ql-admin'))return;
 const q=window.qlQueueSnapshot?.();if(!q)return;
 const waiting=q.waiting||[],history=q.history||[],all=[...waiting,...(q.serving?[q.serving]:[])];
 $('adminWaiting').textContent=waiting.length;
 $('adminServing').textContent=q.serving?.number||'—';
 $('adminCompleted').textContent=q.completed||0;
 const depts={};all.forEach(t=>{const d=t.department||'Unassigned';depts[d]=(depts[d]||0)+1});
 $('adminDepartments').textContent=Object.keys(depts).length;
 const list=$('adminDepartmentList');list.replaceChildren();
 if(!Object.keys(depts).length)list.textContent='No active departments in the queue.';
 Object.entries(depts).sort((a,b)=>b[1]-a[1]).forEach(([name,count])=>{
 const line=document.createElement('div');line.className='admin-dept-row';
 const label=document.createElement('span');label.textContent=name;
 const value=document.createElement('strong');value.textContent=count+' patient'+(count===1?'':'s');
 line.append(label,value);list.append(line);
 });
 const activity=$('adminActivity');activity.replaceChildren();
 const events=[...history.slice(-5).reverse().map(t=>({title:'Completed · '+t.number,detail:(t.name||'Patient')+' — '+(t.department||'Unassigned')})),...waiting.slice(0,3).map(t=>({title:'Waiting · '+t.number,detail:(t.name||'Patient')+' — '+(t.department||'Unassigned')}))];
 if(!events.length)activity.textContent='No activity recorded.';
 events.forEach(ev=>{const row=document.createElement('div');row.className='admin-activity-row';const title=document.createElement('strong');title.textContent=ev.title;const detail=document.createElement('span');detail.textContent=ev.detail;row.append(title,detail);activity.append(row)});
}
const oldStaffRender=window.qlStaffRender;
window.qlStaffRender=()=>{oldStaffRender?.();adminRender();window.qlRenderReports?.()};
$('adminDownload').addEventListener('click',()=>{
 if(!document.body.classList.contains('ql-admin'))return;
 const q=window.qlQueueSnapshot?.();if(!q)return;
 const rows=[['Status','Token','Patient','Department'],...(q.waiting||[]).map(t=>['Waiting',t.number,t.name,t.department]),...(q.serving?[['Serving',q.serving.number,q.serving.name,q.serving.department]]:[]),...(q.history||[]).map(t=>['Completed',t.number,t.name,t.department])];
 const csv=rows.map(row=>row.map(v=>'"'+String(v||'').replace(/"/g,'""')+'"').join(',')).join('\\r\\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='queueless-admin-report.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});
window.qlSetStaffRole=role=>{
 document.body.classList.toggle('ql-admin',role==='admin');
 document.querySelector('#staffTop h1').textContent=role==='admin'?'Admin Dashboard':'Staff Dashboard';
 document.querySelector('#staffTop .dash-eyebrow').textContent=role==='admin'?'ADMINISTRATOR WORKSPACE':'HOSPITAL WORKSPACE';
 adminRender();
};
$('adminReset').addEventListener('click',()=>{
 if(!document.body.classList.contains('ql-admin'))return;
 if(!confirm('Reset the queue and completed visit history on this browser?'))return;
 localStorage.removeItem('queueless_shared_queue_v1');
 window.qlStaffRender?.();
 $('adminNotice').textContent='Queue has been reset.';
});
$('staffLogout').addEventListener('click',()=>document.body.classList.remove('ql-admin'));
})();
