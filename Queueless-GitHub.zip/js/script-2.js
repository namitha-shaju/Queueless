(()=>{
const key='queueless_shared_queue_v1';const $=id=>document.getElementById(id);
const seed=()=>({waiting:Array.from({length:5},(_,i)=>({number:'QL-'+String(19+i).padStart(3,'0'),name:'Patient '+(i+1),department:'General Medicine',joinedAt:null,example:true})),serving:{number:'QL-018',name:'Patient',department:'General Medicine',example:true},completed:0,skipped:[]});
const get=()=>{try{const q=JSON.parse(localStorage.getItem(key));if(q&&Array.isArray(q.waiting))return q}catch(e){}const q=seed();localStorage.setItem(key,JSON.stringify(q));return q};
const save=q=>{localStorage.setItem(key,JSON.stringify(q));render()};
window.qlQueueSnapshot=get;
window.qlGenerateUniqueToken=(department,visitDate)=>{
 const prefixes={'Cardiology':'CARDIO','Orthopedics':'ORTHO','Neurology':'NEURO','Pediatrics':'PEDIA','General Medicine':'GEN','Ophthalmology':'OPHTH','Dentistry':'DENT','Dermatology':'DERMA'};
 const prefix=prefixes[department]||String(department||'QUEUE').replace(/[^A-Za-z]/g,'').toUpperCase().slice(0,8);
 const registryKey='queueless_department_token_registry_v1';
 let registry={};
 try{registry=JSON.parse(localStorage.getItem(registryKey)||'{}')||{}}catch(e){}
 const date=visitDate||new Date().toLocaleDateString('en-CA');
 const dayKey=date+'|'+prefix;
 const issued=new Set(Array.isArray(registry[dayKey])?registry[dayKey]:[]);
 const q=get();
 const all=[...(q.waiting||[]),...(q.serving?[q.serving]:[]),...(q.history||[]),...(q.skipped||[])];
 for(let i=0;i<localStorage.length;i++){
   const k=localStorage.key(i);
   if(!k||!k.startsWith('ql_tokens_'))continue;
   try{const tokens=JSON.parse(localStorage.getItem(k)||'[]');if(Array.isArray(tokens))all.push(...tokens)}catch(e){}
 }
 for(const t of all){if(t.number&&t.number.startsWith(prefix+'-')&&(!t.date||t.date===date))issued.add(t.number)}
 const available=[];
 for(let i=1;i<=999;i++){
   const candidate=prefix+'-'+String(i).padStart(3,'0');
   if(!issued.has(candidate))available.push(candidate);
 }
 if(!available.length)throw new Error('No available token numbers for this department and date.');
 const random=new Uint32Array(1);
 crypto.getRandomValues(random);
 const number=available[random[0]%available.length];
 issued.add(number);
 registry[dayKey]=[...issued];
 localStorage.setItem(registryKey,JSON.stringify(registry));
 return number;
};

window.qlAddToQueue=t=>{const q=get();if(![...(q.waiting||[]),...(q.serving?[q.serving]:[]),...(q.history||[]),...(q.skipped||[])].some(x=>x.number===t.number)){q.waiting.push({...t,joinedAt:Date.now(),createdAt:Date.now()});save(q)}};
function render(){
 const q=get();q.history=Array.isArray(q.history)?q.history:[];q.skipped=Array.isArray(q.skipped)?q.skipped:[];
 $('staffWaiting').textContent=q.waiting.length;
 $('staffServing').textContent=q.serving?.number||'—';
 $('staffNow').textContent=q.serving?.number||'—';
 $('staffNext').textContent=q.waiting[0]?.number||'—';
 $('staffCompleted').textContent=q.completed||0;
 $('staffTotal').textContent=q.waiting.length+(q.serving?1:0)+(q.completed||0);
 $('staffEta').textContent=(q.waiting.length*5)+' min';
 $('staffCall').disabled=!q.waiting.length;
 $('staffComplete').disabled=!q.serving;
 $('staffSkip').disabled=!q.serving;
 const search=$('staffSearch').value.trim().toLowerCase(),dept=$('staffDepartment').value;
 const filtered=q.waiting.map((t,i)=>({t,i})).filter(({t})=>(!dept||t.department===dept)&&(!search||[t.name,t.number,t.department].some(v=>String(v||'').toLowerCase().includes(search))));
 $('staffRows').replaceChildren();
 filtered.forEach(({t,i})=>{
  const tr=document.createElement('tr');
  [String(i+1),t.number,t.name||'Patient',t.department||'—','Waiting'].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td)});
  const td=document.createElement('td'),btn=document.createElement('button');btn.className='staff-row-action';btn.textContent='Call Patient';
  btn.onclick=()=>{const fresh=get();if(fresh.serving){$('staffNotice').textContent='Complete the current visit before calling another patient.';return}const idx=fresh.waiting.findIndex(x=>x.number===t.number);if(idx<0)return;fresh.serving={...fresh.waiting.splice(idx,1)[0],calledAt:Date.now()};save(fresh);$('staffNotice').textContent='Called '+t.number};
  td.append(btn);tr.append(td);$('staffRows').append(tr)
 });
 $('staffEmpty').hidden=filtered.length>0;
 $('staffHistoryRows').replaceChildren();
 q.history.slice(-15).reverse().forEach(t=>{const tr=document.createElement('tr');[t.number,t.name||'Patient',t.department||'—',t.completedAt||'—'].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td)});$('staffHistoryRows').append(tr)});
 $('staffHistoryEmpty').hidden=q.history.length>0;
 window.qlRenderReports?.();
 const t=JSON.parse(sessionStorage.getItem('queuelessToken')||'null');
 if(t?.joined){const pos=q.waiting.findIndex(x=>x.number===t.number);const serving=q.serving?.number===t.number;const ahead=pos<0?0:pos;$('nowServing').textContent=q.serving?.number||'—';$('peopleAhead').textContent=serving?'0':pos<0?'—':String(ahead);$('waitTime').textContent=serving?'Now':pos<0?'—':(ahead*5)+' min';$('queueMessage').textContent=serving?'Your token is being served.':pos<0?'Your token is no longer in the waiting line.':ahead+' patient(s) ahead of you.';$('queueLine').replaceChildren();q.waiting.slice(0,12).forEach(x=>{const c=document.createElement('div');c.className='queue-person'+(x.number===t.number?' mine':'');const b=document.createElement('strong');b.textContent=x.number;c.append(b,document.createTextNode(x.number===t.number?'You':'Waiting'));$('queueLine').append(c)})}
}
function completeCurrent(q){if(!q.serving)return null;const t=q.serving;q.history=Array.isArray(q.history)?q.history:[];q.history.push({...t,completedAt:new Date().toLocaleString(),completedAtMs:Date.now()});q.completed=(q.completed||0)+1;q.serving=null;return t}
$('staffSearch').addEventListener('input',render);
$('staffDepartment').addEventListener('change',render);
$('staffExport').addEventListener('click',()=>{
 const q=get(), rows=[['Position','Token','Patient','Department','Status'],...q.waiting.map((t,i)=>[i+1,t.number,t.name||'',t.department||'','Waiting'])];
 const csv=rows.map(row=>row.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\\r\\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='queueless-queue.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)
});

window.qlStaffRender=render;
window.qlQueueSave=save;
$('staffCall').onclick=()=>{const q=get();if(!q.waiting.length)return;if(q.serving){$('staffNotice').textContent='Complete the current visit first.';return}q.serving={...q.waiting.shift(),calledAt:Date.now()};save(q);$('staffNotice').textContent='Called '+q.serving.number};
$('staffComplete').onclick=()=>{const q=get();if(!q.serving)return;const n=q.serving.number;completeCurrent(q);save(q);$('staffNotice').textContent='Completed '+n};
$('staffSkip').onclick=()=>{const q=get();if(!q.serving)return;q.skipped=Array.isArray(q.skipped)?q.skipped:[];q.skipped.push({...q.serving,skippedAtMs:Date.now()});const n=q.serving.number;q.serving=null;save(q);$('staffNotice').textContent='Skipped '+n};
$('staffLogout').onclick=()=>{document.body.classList.remove('staff-active');location.hash='home';window.scrollTo(0,0)};
$('staffMenu').onclick=()=>$('staffSidebar').classList.toggle('closed');
document.querySelectorAll('[data-staff-go]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-staff-go]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');$(b.dataset.staffGo).scrollIntoView({behavior:'smooth'});if(innerWidth<=850)$('staffSidebar').classList.add('closed')});
window.addEventListener('storage',e=>{if(e.key===key)render()});render();
})();
