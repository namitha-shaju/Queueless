# Queueless
### Hospital Queue & Token Management

A front-end hospital queue management project built to make token booking and queue tracking easier to navigate.

Queueless brings patient-facing tools and an admin workspace into a single browser-based experience. The interface uses a burgundy-led colour palette, responsive layouts and department-based token numbers.

## Features

**Patient portal**
- Login and registration interface
- Dashboard with queue overview
- Department-based token booking
- Token receipt and print option
- Join-queue controls and queue status
- Profile details and booked token history

**Admin workspace**
- Queue monitoring and management controls
- Department and activity information
- Reports covering daily volume, waiting time, service time, peak hours, and completed/skipped tokens
- CSV export options

## Built with

HTML5 · CSS3 · Vanilla JavaScript

No frameworks or build tools are required.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a browser.
3. Use the navigation to explore Queueless.

All CSS and JavaScript files are included in the repository. Keep the folder structure unchanged so the linked assets load correctly.

## Project structure

```text
Queueless/
├── index.html
├── css/
│   └── style-1.css ... style-8.css
├── js/
│   └── script-1.js ... script-4.js
└── README.md
```

The numbered stylesheets and scripts retain the original load order of the source project.

## GitHub Pages

In your repository, open **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.

The published address will follow this pattern:

`https://YOUR-USERNAME.github.io/Queueless/`

## Current scope

Queueless is a **front-end prototype**. Browser storage is used for local state; it is not a shared hospital database. Authentication, live multi-user queues, and globally unique tokens would require a secure backend.

Use sample information when testing the published site. Do not enter real patient records or passwords.

---

**Queueless** — Skip the Queue. Save Your Time.
